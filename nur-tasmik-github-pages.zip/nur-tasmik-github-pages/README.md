# 🌙 NUR Tasmik Web App

Sistem rekod tasmik untuk murid sekolah rendah secara digital.

Built for GitHub Pages deployment.